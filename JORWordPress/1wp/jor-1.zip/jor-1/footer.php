<?php if (!defined('ABSPATH')) exit; echo jor_fill(jor_meta('_jor_bottom')); ?>
<?php wp_footer(); ?>
</body>
</html>
