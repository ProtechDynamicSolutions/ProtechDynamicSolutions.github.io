<?php
/* JOR Ireland 1 (the copy): the JOR Ireland pages as they were built, with WordPress underneath. Page text and pictures are edited in the
   block editor; the header, menus and footer live in this theme (parts/), one set per language. */
if (!defined('ABSPATH')) exit;
define('JOR_MODE', 'copy');
function jor_meta($k, $id = null) { $id = $id ?: get_queried_object_id(); return $id ? (string) get_post_meta($id, $k, true) : ''; }
function jor_fill($html) {
  return str_replace(array('{{THEME}}', '{{HOME}}'), array(get_template_directory_uri(), untrailingslashit(home_url())), $html);
}
function jor_lang() { $l = jor_meta('_jor_lang'); return (strpos($l, 'fr') === 0) ? 'fr' : 'en'; }
add_action('after_setup_theme', function () { add_theme_support('editor-styles'); add_editor_style('assets/editor.css'); });
add_action('wp_enqueue_scripts', function () {
  wp_dequeue_style('global-styles'); wp_dequeue_style('classic-theme-styles');
  if (JOR_MODE === 'built') {
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('jor', get_template_directory_uri() . '/assets/jor.css', array(), $v);
    wp_enqueue_script('jor', get_template_directory_uri() . '/assets/jor.js', array(), $v, array('in_footer' => true, 'strategy' => 'defer'));
  }
}, 20);
remove_action('wp_head', 'print_emoji_detection_script', 7); remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'rel_canonical'); remove_action('wp_head', 'wp_generator');
add_filter('show_admin_bar', '__return_false');
/* the words exactly as written: no curly-quote or smiley substitutions */
add_filter('run_wptexturize', '__return_false');
remove_filter('the_content', 'convert_smilies', 20); remove_filter('the_content', 'capital_P_dangit', 11); remove_filter('the_title', 'capital_P_dangit', 11);
add_filter('the_content', 'jor_fill', 99);
/* parent pages that only hold an address (/en/, /connect/en/ …) send visitors to the language's home page */
add_action('template_redirect', function () {
  $to = jor_meta('_jor_redirect');
  if ($to && !is_admin()) { wp_safe_redirect(home_url($to), 302); exit; }
});
/* a small "Edit this page" button for anyone signed in, since the admin bar is hidden on the pages */
add_action('wp_footer', function () {
  if (!is_user_logged_in() || !is_singular()) return;
  $u = get_edit_post_link(get_queried_object_id());
  if ($u) echo '<a class="jor-edit" href="' . esc_url($u) . '" style="position:fixed;left:16px;bottom:16px;z-index:9999;background:#14231c;color:#fff;font:600 14px/1 system-ui,sans-serif;padding:12px 16px;border-radius:999px;text-decoration:none;box-shadow:0 6px 18px rgba(0,0,0,.25)">Edit this page</a>';
});
/* on first switch to the theme: the home page in front, addresses like /en/golf-dmc-ireland/ */
add_action('after_switch_theme', 'jor_settings');
function jor_settings() {
  update_option('permalink_structure', '/%postname%/');
  $h = get_posts(array('post_type' => 'page', 'name' => 'home', 'post_parent' => 0, 'numberposts' => 1));
  if ($h) { update_option('show_on_front', 'page'); update_option('page_on_front', $h[0]->ID); }
  update_option('blogname', "Joe O'Reilly Ireland DMC");
  flush_rewrite_rules();
}
