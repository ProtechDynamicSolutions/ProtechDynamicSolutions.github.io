<?php if (!defined('ABSPATH')) exit; ?><!doctype html>
<html lang="<?php echo esc_attr(jor_meta('_jor_lang') ?: 'en'); ?>">
<head>
<?php echo jor_fill(jor_meta('_jor_head')); ?>
<?php wp_head(); ?>
</head>
<body class="<?php echo esc_attr(jor_meta('_jor_body')); ?>">
<?php echo jor_fill(jor_meta('_jor_top')); ?>
