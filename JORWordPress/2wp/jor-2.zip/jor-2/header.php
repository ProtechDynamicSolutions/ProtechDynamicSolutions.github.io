<?php if (!defined('ABSPATH')) exit; $lang = jor_lang(); $pre = get_template_directory();
$langs = json_decode(jor_meta('_jor_langs'), true) ?: array();
$lhtml = ''; foreach ($langs as $l) { $lhtml .= '<a href="' . esc_url(jor_fill(($l['href'][0] === '/') ? '{{HOME}}' . $l['href'] : $l['href'])) . '"' . (!empty($l['cur']) ? ' class="cur"' : '') . '>' . esc_html($l['text']) . '</a>'; }
?><!doctype html>
<html lang="<?php echo esc_attr(jor_meta('_jor_lang') ?: 'en'); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?php echo esc_html(jor_meta('_jor_title') ?: wp_get_document_title()); ?></title>
<meta name="description" content="<?php echo esc_attr(jor_meta('_jor_desc')); ?>">
<?php if (jor_meta('_jor_canonical')): ?><link rel="canonical" href="<?php echo esc_url(jor_meta('_jor_canonical')); ?>"><?php endif; ?>
<?php foreach ((json_decode(jor_meta('_jor_alts'), true) ?: array()) as $a): ?><link rel="alternate" hreflang="<?php echo esc_attr($a['lang']); ?>" href="<?php echo esc_url($a['href']); ?>">
<?php endforeach; ?>
<?php if (jor_meta('_jor_og')): ?><meta property="og:image" content="<?php echo esc_url(jor_meta('_jor_og')); ?>"><?php endif; ?>
<meta name="theme-color" content="#0a9f68">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-EH4Z63LNV6"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','G-EH4Z63LNV6');</script>
<?php wp_head(); ?>
</head>
<body id="top" class="<?php echo esc_attr(jor_meta('_jor_body')); ?>">
<?php if (jor_meta('_jor_map')) echo file_get_contents($pre . '/parts/base-map.svg'); ?>
<?php $hp = preg_replace('/[^a-z0-9-]/', '', jor_meta('_jor_hdr')) ?: 'header-' . $lang;
echo str_replace('<!--JOR:LANG-->', $lhtml, jor_fill(file_get_contents($pre . '/parts/' . $hp . '.html'))); ?>
