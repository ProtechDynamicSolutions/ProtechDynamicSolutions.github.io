<?php if (!defined('ABSPATH')) exit; $fp = preg_replace('/[^a-z0-9-]/', '', jor_meta('_jor_ftr')) ?: 'footer-' . jor_lang();
echo jor_fill(file_get_contents(get_template_directory() . '/parts/' . $fp . '.html')); ?>
<script async defer id="hs-script-loader" src="https://js-eu1.hs-scripts.com/19825762.js"></script>
<?php wp_footer(); ?>
</body>
</html>
