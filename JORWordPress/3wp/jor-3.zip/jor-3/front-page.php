<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<main><?php while (have_posts()) { the_post(); the_content(); } ?></main>
<?php get_footer();
