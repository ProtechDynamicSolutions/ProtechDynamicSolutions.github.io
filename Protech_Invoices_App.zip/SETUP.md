# Protech Invoices - Setup

Everything is now backed by **your own Google account**: data lives in a Google Sheet, invoice PDFs and receipt photos land in Google Drive, and the app installs on your phone with your logo. On open it asks for one password, which unlocks an encrypted copy of your connection details held on the device.

## What is in this folder

```
index.html              the app (single file)
manifest.webmanifest    PWA manifest (makes it installable)
sw.js                   service worker (install + offline shell)
icons/                  app icons generated from your logo
Protech_Backend.gs      the Google Apps Script backend
```

## Step 1 - Deploy the backend (about 3 minutes)

1. Go to https://script.google.com and click **New project**.
2. Delete the sample code, paste in all of `Protech_Backend.gs`.
3. Near the top, change `APP_PASSWORD` from `change-this-password` to your own private password.
4. Click **Deploy > New deployment**.
   - Type: **Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
5. Click **Deploy**, then **Authorise access** and allow the permissions.
6. Copy the **Web app URL** (it ends in `/exec`). You will paste this into the app once.

The Google Sheet (`Protech Invoice Data`) and the Drive folders (`Protech Dynamic Solutions/Invoices`, `/Quotes`, `/Receipts`) are created automatically the first time the app talks to the script. No manual setup needed.

## Step 2 - Publish the app on GitHub Pages

Drop `index.html`, `manifest.webmanifest`, `sw.js` and the `icons` folder into your `ProtechDynamicSolutions.github.io` repo (keep the `icons/` folder intact). Push. It is then live at your GitHub Pages URL.

A PWA must be served over HTTPS for install and the service worker to work. GitHub Pages already is, so you are grand.

## Step 3 - First open

1. Open the GitHub Pages URL on your phone or laptop.
2. It asks for the **Apps Script URL** and a **password**. Use the same password you set in step 3 above.
3. Tap connect. From now on it only asks for the password.

## Step 4 - Install on your phone

- **iPhone (Safari):** Share button, then **Add to Home Screen**. The Protech icon appears and opens fullscreen.
- **Android (Chrome):** the **Install app** prompt appears, or use the menu, then **Install app / Add to Home screen**.

## Moving your old data across

Open the app, go to **Settings**:

- **Migrate device data** pushes anything stored locally (including the old app's saved invoices) into the Sheet.
- **Import InvoiceData.csv** reads your existing CSV and loads it into the Sheet. Duplicates are skipped, so you can run either safely more than once.

## How the security works

The Apps Script URL and password are encrypted on the device with AES-GCM, using a key derived from your password (PBKDF2, 310k rounds, Web Crypto). The plaintext only exists in memory while the app is unlocked. Close or reload, and it is locked again. Someone holding the device cannot read the connection details without the password. **Forget this device** in Settings wipes the encrypted copy; your data stays safe in Google Sheets.

## Notes

- VAT line stays as `VAT (Not registered)` and totals are exclusive, unchanged from before.
- Receipts capture supplier, category, amount, VAT, payment method, a note and a photo or PDF, all going to the Sheet plus Drive so the accountant has one tidy place.
- Saving an invoice writes the record to the Sheet and uploads the PDF to Drive automatically. The **PDF Copy** button still gives you a local download when you want one.
